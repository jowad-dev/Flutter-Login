# app

A Flutter app, run on this device by the Dart plugin's Flutter player.

- `lib/main.dart` is the app. Press Run: it starts in the player, and every file you save hot-reloads
  into it, keeping its state. In the Run console, type `r` to hot reload, `R` to restart, `q` to quit.
- Functions marked `@Preview` show in "Preview widgets" in the Run menu: every preview in `lib/` in one
  gallery, hot-reloading as you save.
- Add packages in `pubspec.yaml`; saving it runs `pub get` and restarts the app. Packages with their own
  Android code (plugins) do not work in the player.
- This is debug mode only: release builds (AOT) are not something the device can make.
